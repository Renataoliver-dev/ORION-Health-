# ORION — Movement tracking and session history

ORION combines a React dashboard, FastAPI, SQLite, and two pose engines. Movement tracking supports Orion YOLO-Pose and MediaPipe. Finish a session to save its assessment, repetition counts, and sampled angles.

## Requirements

- Python 3.11+ with virtual environment support.
- Node.js 20.19+ or 22.12+ with npm. Use Node.js 22.18+ for the movement tests.
- An Orion Dataset directory with the supplied checkpoint and MediaPipe model. See [models and rules](docs/MOVEMENT.md).

## Zorin OS / Ubuntu

In the first terminal, from the project root:

```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements-pose.txt
export ORION_DATASET_DIR="/absolute/path/to/Orion_dataset"
python -m alembic upgrade head
python -m uvicorn main:app --host 127.0.0.1 --port 8000
```

In a second terminal, from the project root:

```bash
cd frontend
npm ci
npm run dev -- --host 127.0.0.1
```

Open the address Vite prints, usually `http://127.0.0.1:5173`. Vite proxies requests to the API on port 8000. Set `VITE_BACKEND_PROXY_TARGET` in `frontend/.env` if the API uses another address.

## Windows PowerShell

```powershell
cd backend
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-pose.txt
$env:ORION_DATASET_DIR = 'C:/Users/Lavynne/Documents/Orion_dataset'
.\.venv\Scripts\python.exe -m alembic upgrade head
.\.venv\Scripts\python.exe -m uvicorn main:app --host 127.0.0.1 --port 8000
```

In a second PowerShell window, run `npm ci` and `npm run dev -- --host 127.0.0.1` from `frontend`.

## Use the application

1. Open **Overview**, register or open a pseudonymous crew profile, and keep its UUID.
2. Open **Movement**. Choose an exercise, a side when applicable, and a pose engine. Enable the camera and grant browser permission.
3. Select **Start server session**, then **Start pose tracking**. Follow the phase feedback and keep the relevant joints in view.
4. Select **Finish server session**. In **History**, view the engine, session duration, results, and saved joint measurements.
5. For recorded external measurements, **Movement** also accepts JSON batches of 1–50 samples in an open session. See [API contracts](docs/API_CONTRACTS.md).

Body Profile, Atlas, and the exercise advisor retain their existing workflows. Keep this research prototype local and use de-identified data. Camera video and images are processed in memory. The database stores session metadata, derived measurements, and rule results.

## Runtime configuration

| Variable | Default or example |
|---|---|
| `ORION_DATASET_DIR` | Absolute path to the supplied Orion Dataset |
| `ORION_POSE_WEIGHTS` | `fitness_pose/runs/pose/custom_finetune/weights/best.pt`, relative to the dataset unless an absolute path is provided |
| `ORION_POSE_DEVICE` | `cpu`. Set `auto` to use a CUDA-enabled PyTorch installation when it detects a compatible GPU |
| `ORION_DB_PATH` | `backend/orion.db`. Use the same setting for Alembic and FastAPI |

For NVIDIA acceleration on Zorin, verify the driver with `nvidia-smi` and verify the selected PyTorch installation with `python -c "import torch; print(torch.cuda.is_available(), torch.version.cuda)"`. The default CPU path works without CUDA. `GET /api/v1/pose/model` reports the selected device and the checkpoint identifier.

Run the checks documented in [Validation](docs/VALIDATION.md).
