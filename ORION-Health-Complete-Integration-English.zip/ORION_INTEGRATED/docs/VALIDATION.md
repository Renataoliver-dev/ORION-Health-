# Validation

## Verified on Windows

- TypeScript, ESLint, and the Vite production build passed.
- Seven movement tests passed. The movement inputs were simulated joint-angle sequences for four exercises, a squat asymmetry case, and a tracking gap. The mapping test used fixture coordinates.
- The API started on a local port. Alembic created a fresh database and upgraded a database containing an existing squat session. The existing result remained accessible.
- The trained Orion checkpoint ran on CPU and returned 15 keypoints for a real validation image. The API checks covered a uniform frame, malformed JPEG data, content type, and the size limit.
- Live HTTP and SQLite checks covered athlete creation, creating and retrieving sessions, rollback on an incompatible engine, sample deduplication, atomic finish, idempotent retry, and session history. The assessment values in this persistence test were fixtures.
- Chrome used a virtual camera carrying a real dataset image. Both YOLO-Pose and the supplied MediaPipe Full model rendered a skeleton. The browser test confirmed MediaPipe worker results, Vite forwarding, and saved joint measurements in History.
- The 15 existing exercise-advisor tests passed.
- Physical webcam access, CUDA execution, and Zorin OS execution remain to be verified. The test machine reported a CPU-only PyTorch build.

## Run the automated checks

From `frontend` with dependencies installed and Node.js 22.18 or newer:

```bash
npm run build
npm run lint
npm test
```

From `backend` with the pose dependencies installed and `ORION_DATASET_DIR` set:

```bash
python tests/integration_check.py
```

The script starts Uvicorn on port 18000 and creates a temporary SQLite database. Use `--port` to select another port. If the dataset moved from its original location and the validation manifest uses outdated absolute paths, pass `--image /path/to/a/validation-image.jpg`.

The existing advisor checks can be run with `python -m unittest discover -s tests -p test_exercise_advisor.py` after installing `httpx` in the test environment.

## Manual camera check

Start both services using the [main README](../README.md). In **Movement**, select **Orion Dataset · YOLO-Pose** and enable the camera. Start a session and pose tracking, then check the skeleton and phase guidance as you move. Finish the session and verify its assessment and measurements in **History**. Repeat with **MediaPipe**. Use a clear view of the relevant joints.
