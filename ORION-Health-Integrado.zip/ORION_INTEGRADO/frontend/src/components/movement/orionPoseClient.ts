import { apiRequest } from '../../services/apiClient';
import type { PoseDetector, PoseLandmark } from './poseClient';

// Orion's 15-point annotation order, mapped to the indices used by the dashboard.
const dashboardIndices = [0, 11, 12, 13, 14, 15, 16, 23, 24, 25, 26, 27, 28] as const;

export async function createOrionPoseDetector(): Promise<PoseDetector> {
  await apiRequest('/api/v1/pose/model');
  const frameCanvas = document.createElement('canvas');
  const context = frameCanvas.getContext('2d');
  if (!context) throw new Error('Could not initialize camera frame capture.');
  const controller = new AbortController();

  return {
    async detectForVideo(video) {
      const scale = Math.min(1, 640 / Math.max(video.videoWidth, video.videoHeight));
      frameCanvas.width = Math.max(1, Math.round(video.videoWidth * scale));
      frameCanvas.height = Math.max(1, Math.round(video.videoHeight * scale));
      context.drawImage(video, 0, 0, frameCanvas.width, frameCanvas.height);
      const image = await new Promise<Blob>((resolve, reject) => {
        frameCanvas.toBlob(blob => {
          if (blob) resolve(blob);
          else reject(new Error('Could not encode the camera frame.'));
        }, 'image/jpeg', 0.8);
      });
      const { keypoints } = await apiRequest<{ keypoints: PoseLandmark[] }>('/api/v1/pose/frame', {
        method: 'POST',
        headers: { 'Content-Type': 'image/jpeg' },
        body: image,
        signal: controller.signal,
      });
      if (keypoints.length === 0) return { landmarks: [] };

      const points: PoseLandmark[] = Array.from({ length: 33 }, () => ({ x: 0, y: 0, visibility: 0 }));
      dashboardIndices.forEach((dashboardIndex, index) => {
        points[dashboardIndex] = keypoints[index];
      });
      return { landmarks: [points] };
    },
    close() {
      controller.abort();
    },
  };
}
