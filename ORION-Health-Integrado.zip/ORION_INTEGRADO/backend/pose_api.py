import io
import logging
import os
from functools import lru_cache
from pathlib import Path
from threading import Lock

from fastapi import APIRouter, HTTPException, Request
from starlette.concurrency import run_in_threadpool

router = APIRouter(prefix="/api/v1/pose", tags=["pose"])
log = logging.getLogger(__name__)
model_lock = Lock()
MAX_FRAME_BYTES = 512 * 1024
DEFAULT_WEIGHTS = Path("fitness_pose/runs/pose/custom_finetune/weights/best.pt")


@lru_cache(maxsize=1)
def load_model():
    dataset = os.environ.get("ORION_DATASET_DIR")
    if not dataset:
        raise HTTPException(503, "Set ORION_DATASET_DIR to the Orion Dataset folder.")
    weights = Path(dataset) / os.environ.get("ORION_POSE_WEIGHTS", DEFAULT_WEIGHTS)
    if not weights.is_file() or weights.suffix.lower() != ".pt":
        raise HTTPException(503, "The configured Orion YOLO-Pose checkpoint was not found.")
    try:
        os.environ.setdefault("YOLO_CONFIG_DIR", str(Path(__file__).resolve().parent / ".ultralytics"))
        from ultralytics import YOLO

        model = YOLO(str(weights.resolve()))
        if model.task != "pose" or list(model.model.yaml.get("kpt_shape", [])) != [15, 3]:
            raise ValueError("Expected the Orion 15-point pose model.")
    except Exception as error:
        log.exception("Could not load the Orion pose checkpoint")
        raise HTTPException(503, "Could not load the Orion 15-point YOLO-Pose model.") from error
    return model


@router.get("/model")
def pose_model():
    with model_lock:
        load_model()
    return {"model": "orion-yolo-pose", "keypoints": 15}


def predict_frame(frame: bytes):
    try:
        from PIL import Image, UnidentifiedImageError
    except ImportError as error:
        raise HTTPException(503, "Install the ORION pose dependencies first.") from error

    try:
        with Image.open(io.BytesIO(frame), formats=["JPEG"]) as image:
            if max(image.size) > 1280:
                raise HTTPException(422, "Frame dimensions must be at most 1280 pixels.")
            rgb = image.convert("RGB")
    except (UnidentifiedImageError, OSError, Image.DecompressionBombError) as error:
        raise HTTPException(422, "Send a valid JPEG frame.") from error

    with model_lock:
        model = load_model()
        try:
            result = model.predict(rgb, imgsz=640, conf=0.4, max_det=1, device="cpu", verbose=False)[0]
        except Exception as error:
            log.exception("Orion pose inference failed")
            raise HTTPException(503, "YOLO-Pose could not process the frame.") from error

    if result.keypoints is None or len(result.keypoints) == 0:
        return {"keypoints": []}

    coordinates = result.keypoints.xyn[0].cpu().tolist()
    confidence = result.keypoints.conf[0].cpu().tolist()
    return {"keypoints": [
        {"x": x, "y": y, "visibility": score}
        for (x, y), score in zip(coordinates, confidence)
    ]}


@router.post("/frame")
async def pose_frame(request: Request):
    if request.headers.get("content-type") != "image/jpeg":
        raise HTTPException(415, "Send a JPEG frame with Content-Type: image/jpeg.")
    body = bytearray()
    async for chunk in request.stream():
        if len(body) + len(chunk) > MAX_FRAME_BYTES:
            raise HTTPException(413, "Frame exceeds 512 KiB.")
        body.extend(chunk)
    return await run_in_threadpool(predict_frame, bytes(body))
