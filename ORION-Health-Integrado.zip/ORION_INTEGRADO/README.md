# ORION — Frontend, API e Orion Dataset

O dashboard React em `frontend` usa a API FastAPI em `backend` para o histórico de sessões e o rastreamento YOLO-Pose treinado no Orion Dataset.

## Requisitos
- Python compatível com as dependências de `backend/requirements.txt`.
- Node.js e npm compatíveis com Vite 8 (Node >=20.19 ou >=22.12, preferencialmente versão LTS).

## Terminal 1 — API, SQLite e Orion Dataset (Windows PowerShell)

Na pasta `ORION_INTEGRADO`, execute:

```powershell
cd backend
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-pose.txt
$env:ORION_DATASET_DIR = 'C:/Users/Lavynne/Documents/Orion_dataset'
.\.venv\Scripts\python.exe -m alembic upgrade head
.\.venv\Scripts\python.exe -m uvicorn main:app --host 127.0.0.1 --port 8000
```

Por padrão, a API carrega `fitness_pose/runs/pose/custom_finetune/weights/best.pt` do dataset. Esse checkpoint foi treinado com `unified_dataset/data.yaml`. Para usar o checkpoint de espaço, defina `$env:ORION_POSE_WEIGHTS = 'fitness_pose/models/best_space_pose.pt'` antes de iniciar a API. Use apenas checkpoints confiáveis com a mesma ordem de 15 pontos do Orion Dataset.

Com a API em execução, `Invoke-RestMethod http://127.0.0.1:8000/api/v1/pose/model` verifica o carregamento do checkpoint. A API usa a CPU e processa os quadros em memória. A pasta de dados continua no caminho original e o modelo não precisa de novo treino para rodar.

## Terminal 2 — dashboard
```bash
cd frontend
npm ci
npm run dev
```
Acesse o endereço que o Vite informar, normalmente `http://localhost:5173`. O frontend usa um proxy Vite `/backend-api` => `http://127.0.0.1:8000`, evitando alterar o CORS existente. Opcional: copie `frontend/.env.example` para `frontend/.env` se o backend usar outra porta e ajuste o destino. **Não crie um `VITE_API_BASE_URL` se quiser usar o proxy padrão**.

## Teste rápido
1. Acesse Overview; em Active crew profile, cadastre um pseudônimo. Salve o UUID mostrado.
2. Em **Movement**, com **Orion Dataset · YOLO-Pose** selecionado, clique em **Enable camera** e **Start pose tracking**. Enquadre o corpo inteiro para ver o esqueleto e, conforme o exercício escolhido, os ângulos e o contador de repetições. **MediaPipe** continua disponível no seletor.
3. Para testar o histórico, escolha **Bodyweight squat**, inicie e finalize uma sessão no servidor, depois consulte **History**.
4. Se tiver dados reais de um rastreador, com a sessão aberta, importe um JSON com 1–50 amostras de movimento usando os campos especificados em `docs/CONTRATOS.md`.
5. Atlas possui a divisão `upper arm` / `forearm` em ambos os lados, conforme a evolução do frontend.

## Observações
- A quantidade de perfis exibida é apenas a do **perfil ativo**, não o total global: não existe rota para listar todos os perfis.
- A quantidade de sessões é o tamanho da lista retornada (até 100 registros), não uma contagem geral do banco.
- O histórico de exame local não é persistido, não há autenticação, criptografia na aplicação ou uso clínico. Use dados de pesquisa desidentificados.
- Evite enviar `node_modules`, `backend/.venv`, bancos `.db` e imagens pessoais ao compartilhar o ZIP.
