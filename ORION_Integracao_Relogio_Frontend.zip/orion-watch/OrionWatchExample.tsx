import { useOrionWatch } from './useOrionWatch';

/** Optional example: replace this markup with your own frontend design. */
export default function OrionWatchExample() {
  const watch = useOrionWatch();
  const time = (timestamp: number | null) => timestamp == null ? 'No reading' : new Date(timestamp).toLocaleString('en-US');
  return (
    <section aria-label="ORION watch data">
      <h2>ORION Wear</h2>
      <p>{!watch.receiverOnline ? 'Receiver offline' : watch.connected ? 'Receiving watch data' : 'Waiting for watch'}</p>
      <dl>
        <dt>Heart rate</dt>
        <dd>{watch.heartRate.value == null ? '—' : `${watch.heartRate.value} bpm`}</dd>
        <dt>Blood oxygen · last spot reading</dt>
        <dd>{watch.oxygen.value == null ? '—' : `${watch.oxygen.value} %`}<small> · Received: {time(watch.oxygen.receivedAt)}</small></dd>
        <dt>Sleep session duration</dt>
        <dd>{watch.sleepSession.value == null ? '—' : `${watch.sleepSession.value} min`}<small> · {watch.sleepSessionActive ? 'Recording' : 'No active session'}</small></dd>
      </dl>
      <p>Sleep session time is not estimated time asleep. Missing readings are never replaced with invented values.</p>
    </section>
  );
}
