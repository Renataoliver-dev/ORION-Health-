import { useEffect, useState } from 'react';

export type OrionMetric = { value: number | null; receivedAt: number };
export type OrionHealth = {
  metrics: Record<string, OrionMetric | undefined>;
  receivedAt: number | null;
  source: string | null;
  serverTime: number;
};
export type OrionReading = { value: number | null; receivedAt: number | null; stale: boolean };

/** Reads the existing ORION receiver through your frontend's private server proxy. */
export function useOrionWatch(base = '/watch-api') {
  const [health, setHealth] = useState<OrionHealth | null>(null);
  const [online, setOnline] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [clock, setClock] = useState({ fetchedAt: 0, now: 0 });

  useEffect(() => {
    const controller = new AbortController();
    let disposed = false;
    let busy = false;
    setHealth(null); setOnline(false); setError(null);
    async function update() {
      if (busy || disposed) return;
      busy = true;
      try {
        const signal = AbortSignal.any([controller.signal, AbortSignal.timeout(4000)]);
        const response = await fetch(`${base}/saude`, { signal, cache: 'no-store' });
        if (!response.ok) throw new Error(`Receiver returned HTTP ${response.status}`);
        const data = await response.json() as OrionHealth;
        if (!data.metrics || !Number.isFinite(data.serverTime)) throw new Error('Invalid ORION response');
        if (!disposed) {
          setHealth(data); setOnline(true); setError(null);
          setClock({ fetchedAt: Date.now(), now: Date.now() });
        }
      } catch (reason) {
        if (!disposed) { setOnline(false); setError(reason instanceof Error ? reason.message : 'Receiver unavailable'); }
      } finally { busy = false; }
    }
    void update();
    const timer = setInterval(() => {
      setClock(previous => ({ ...previous, now: Date.now() }));
      void update();
    }, 1000);
    return () => { disposed = true; controller.abort(); clearInterval(timer); };
  }, [base]);

  const serverNow = health ? health.serverTime + Math.max(0, clock.now - clock.fetchedAt) : 0;
  function reading(key: string, maxAge?: number): OrionReading {
    const metric = health?.metrics[key];
    const stale = !online || !metric || metric.value == null ||
      (maxAge !== undefined && serverNow - metric.receivedAt >= maxAge);
    return {
      value: stale ? null : metric!.value,
      receivedAt: metric?.receivedAt ?? null,
      stale,
    };
  }
  const connected = online && health?.receivedAt != null && serverNow - health.receivedAt < 30000;
  return {
    receiverOnline: online,
    connected,
    source: health?.source ?? null,
    heartRate: reading('batimentos_bpm', 30000),
    // SpO2 is the last completed spot measurement, not a continuous/live reading.
    oxygen: reading('oxigenacao_percentual'),
    // This is manually recorded session duration, NOT measured time asleep.
    sleepSession: reading('sleep_session_minutes'),
    sleepSessionActive: connected && health?.metrics.sleep_session_active?.value === 1,
    error,
    raw: health,
  };
}
