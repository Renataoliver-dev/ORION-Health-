// SERVER CONFIGURATION ONLY. Never import this file into src/ or browser code.
// Merge the proxy entry into your EXISTING Vite config; keep its other settings.
import { readFileSync } from 'node:fs';
import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), 'ORION_');
  if (!env.ORION_WATCH_TOKEN_FILE) throw new Error('Set ORION_WATCH_TOKEN_FILE in .env.local');
  const token = readFileSync(env.ORION_WATCH_TOKEN_FILE, 'utf8').trim();
  if (!token) throw new Error('ORION watch token is empty');
  return {
    plugins: [react()],
    server: {
      proxy: {
        '/watch-api': {
          target: env.ORION_WATCH_RECEIVER || 'http://127.0.0.1:8001',
          headers: { Authorization: `Bearer ${token}` },
          rewrite: path => path.replace(/^\/watch-api/, '/api'),
        },
      },
    },
  };
});
