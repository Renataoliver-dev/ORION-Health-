# ORION Wear — frontend integration only

This kit connects another React + Vite frontend to the ORION watch receiver already implemented. It does not replace the watch application or its visual design, and it does not include camera/exercise code, private keys or health records.

## Install in your frontend
1. Copy useOrionWatch.ts into src/integrations/orion/.
2. Optionally copy OrionWatchExample.tsx to the same folder, or use the hook in your own cards.
3. Merge the /watch-api proxy entry from vite.config.example.ts into your existing Vite configuration. Preserve other plugins and proxy routes.
4. Copy .env.local.example to your frontend root as .env.local. Set the receiver URL and the path to the existing private .watch-token file. Do not place the token in browser JavaScript, localStorage, a VITE_ variable or a public repository.
5. Start the existing ORION receiver, then start your frontend. Both apps may run at the same time. The watch sends to the receiver's LAN IP on port 8001; it does NOT send directly to the React page's port.

Use:
```tsx
import { useOrionWatch } from './integrations/orion/useOrionWatch';

function HeartRateCard() {
  const { heartRate, connected } = useOrionWatch();
  return <div>{connected && heartRate.value !== null ? `${heartRate.value} bpm` : 'No recent reading'}</div>;
}
```
Call the hook once in a shared parent or provider when several components use it, to avoid duplicate polling.

## Existing receiver and watch settings
Receiver source on the current computer: /home/carlos/Documentos/files(1)/server/.
Run the existing project's START_ORION.sh (Linux), START_ORION.cmd (Windows) or npm run connected. The startup output prints the selected receiver address. Do not start a second receiver on port 8001.
The watch's Server setting must match the receiver IP. IP addresses can change when switching networks. The frontend proxy target must match too. The watch, receiver and new frontend backend must share access to the same private network. Private HTTP traffic is not encrypted; do not expose this receiver to the public internet.
For another computer, transfer the receiver and its matching private key securely. The key must match the one in the installed ORION Wear build. This kit deliberately does not contain that key or a receiver copy. The receiver requires Node.js 22.13+.

## Data contract
GET /watch-api/saude through your frontend proxy maps to GET /api/saude on the receiver.
Response: { metrics: { metricName: { value: number|null, receivedAt: epochMilliseconds } }, receivedAt: epochMilliseconds|null, source: string|null, serverTime: epochMilliseconds }.
Fields: batimentos_bpm, oxigenacao_percentual, sleep_session_minutes, sleep_session_active, sleep_hr_samples, sleep_motion_samples, sleep_session_id, sleep_session_started_at, sleep_session_ended_at.
The hook polls every second, prevents overlapping requests and expires heart rate after 30 seconds. Oxygen remains explicitly the last spot reading. receivedAt is the receiver arrival time. Sleep is observation-session duration, not measured sleep or sleep stages. No successful oxygen reading has yet been verified on the current device; do not substitute fake values.

Other authenticated receiver endpoints available through the same proxy:
- GET /watch-api/watch/history?limit=20: recent saved readings and sleep sessions.
- GET /watch-api/watch/check-ins: saved wellness questions and responses.
- POST /watch-api/watch/check-ins/:id/response: { source, response }, where response is well, exercising, unwell or sensor_issue.
Wellness rules remain experimental. They are not diagnostic or emergency monitoring.

## Production and other frameworks
Vite's server.proxy is a development server feature. For production, add the equivalent authenticated server-side proxy to your own backend/reverse proxy. Keep the key on that server. For Next.js, Vue or another stack, retain the same HTTP contract and implement its server proxy; this React hook is not directly usable in non-React clients.

## Scope
This kit contains only the connection layer and optional display example. Exercise correlation stays in your exercise backend. The watch application and sensor permissions must already be installed/configured.
